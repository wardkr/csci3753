#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <stdbool.h>

#define DEVICENAME "/dev/simple_character_device"
#define BUFFER_SIZE 1024

int main(){
	char command;
	int length, whence, seek_offset;
	char buffer[BUFFER_SIZE];
	int file = open(DEVICENAME, O_RDWR);
	bool running = true;
	while(running){
		printf("\nSimple Char Driver Test Function\n");
		printf("COMMANDS:\n");
		printf("	'r' to read from device\n");
		printf("	'w' to write to device\n");
		printf("	's' to seek from device\n");
		printf("	'e' to exit from device\n");
		printf("	anything else brings up main menu\n");
		printf("/Simple Char Device/\ncommand$> ");
		scanf("%c", &command);

		switch(command){
			case 'r':
				printf("/Simple Char Device/\nread$> How many bytes do you want to read: ");
				scanf("%d", &length); /* gets number of bytes to read */
				read(file, buffer, length); /* reads from the file and puts it into the buffer */
				printf("/Simple Char Device/\nread$> %s\n", buffer); /* prints the buffer */
				while(getchar() != '\n'); /* continue until newline  */
				break;
			case 'w':
				printf("/Simple Char Device/\nwrite$> ");
				scanf("%s", buffer); /* puts user input into file */
				write(file, buffer, BUFFER_SIZE); /* writes the buffer to file */
				while (getchar() != '\n'); /* continue until newline */
				break;
			case 's':
				printf("SEEK COMMANDS:\n");
				printf("	'0' seek set\n");
				printf("	'1' seek cur\n");
				printf("	'2' seek end\n");
				printf("	anything else brings up main menu\n");
				printf("/Simple Char Device\nseek$> Enter whence: ");
				scanf("%d", &whence);
				printf("\n/Simple Char Device/\nwrite$> Enter an offset value: ");
				scanf("%d", &seek_offset);
				llseek(file, seek_offset, whence);
				break;
			case 'e':
				printf("/Simple Char Driver/\nexit$> Exiting\n");
				running = false;
				break;
			default:
				printf("\n/Simple Char Device/\nerror$> error: not a valid command\n");
				break;
		}
	}
	close(file);
	return 0;
}